from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

# Команда /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привет! Я бот. Напиши /link чтобы получить ссылку.")

# Команда /link
async def link(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Вот ссылка: https://www.un.org/ru/global-issues/climate-change")

# Основной запуск
if __name__ == '__main__':
    app = ApplicationBuilder().token("7718610323:AAGzAI9Sl8M_ZSKugh8IFII48WnnzLZ0deQ").build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("link", link))

    print("Бот запущен...")
    app.run_polling()